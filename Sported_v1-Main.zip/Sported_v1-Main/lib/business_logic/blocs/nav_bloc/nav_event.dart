part of 'nav_bloc.dart';

abstract class NavEvent extends Equatable {
  const NavEvent();
}

class LoadPageOne extends NavEvent {
  @override
  List<Object> get props => [];
}

class LoadPageTwo extends NavEvent {
  @override
  List<Object> get props => [];
}

class LoadPageThree extends NavEvent {
  @override
  List<Object> get props => [];
}

class LoadPageFour extends NavEvent {
  @override
  List<Object> get props => [];
}

class LoadPageFive extends NavEvent {
  @override
  List<Object> get props => [];
}

class LoadVenuesPage extends NavEvent {
  @override
  List<Object> get props => [];
}
