part of 'filter_chips_cubit.dart';

abstract class FilterChipsState extends Equatable {
  const FilterChipsState();
}

class FilterChipsInitial extends FilterChipsState {
  @override
  List<Object> get props => [];
}
