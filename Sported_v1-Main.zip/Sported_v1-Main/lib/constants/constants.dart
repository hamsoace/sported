import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

TextStyle regularStyle = TextStyle(
  color: Color(0xffBBBBBC),
  fontSize: 15.sp,
);

TextStyle labelStyle = TextStyle(
  fontSize: 14.sp,
  color: Color(0xff707070),
);

TextStyle hintStyle = TextStyle(
  fontSize: 12.sp,
  color: Color(0xff707070),
);

String kConsumerKey = "ygmt4jBmWDba1neZU11lfvzpXiKk1uyN";
String kConsumerSecret = "iY5FXEbsLaVjLatM";
